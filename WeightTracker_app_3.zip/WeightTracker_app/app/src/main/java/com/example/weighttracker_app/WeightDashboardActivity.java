
package com.example.weighttracker_app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;
import android.widget.TableRow;
import android.content.SharedPreferences;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import android.telephony.SmsManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.app.Activity;
import androidx.core.content.ContextCompat;



import androidx.appcompat.app.AppCompatActivity;

public class WeightDashboardActivity extends AppCompatActivity {

    private EditText editDate, editWeight, editGoalWeight;
    private TextView textCurrentWeight, textGoalWeight;
    private TableLayout tableWeightHistory;
    private Button buttonAddWeight;
    private DatabaseHelper databaseHelper;
    private int userId;
    private int editingWeightId = -1;
    private Button buttonUpdateGoal;
    private Button buttonNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_dashboard);

        // Open the existing SQLite database.
        databaseHelper = new DatabaseHelper(this);


        // Identify the user who logged in.
        String username = getIntent().getStringExtra("username");

        if (username == null) {
            finish();
            return;
        }

        userId = databaseHelper.getUserId(username);

        if (userId == -1) {
            finish();
            return;
        }


        // Connect the dashboard fields to Java.
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        editGoalWeight = findViewById(R.id.editGoalWeight);

        textCurrentWeight = findViewById(R.id.textCurrentWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        tableWeightHistory = findViewById(R.id.tableWeightHistory);

        buttonAddWeight = findViewById(R.id.buttonAddWeight);

        buttonUpdateGoal = findViewById(R.id.buttonUpdateGoal);

        buttonNotifications = findViewById(R.id.buttonNotifications);


        // Ask for SMS permission when the user selects notifications.
        buttonNotifications.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        100);
            } else {
                Toast.makeText(this,
                        "SMS permission already granted",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Save each user's goal weight.
        SharedPreferences preferences = getSharedPreferences(
                "WeightGoals", MODE_PRIVATE);

        String goalKey = "goal_" + userId;

        double savedGoal = Double.longBitsToDouble(
                preferences.getLong(goalKey,
                        Double.doubleToLongBits(0.0)));

        if (savedGoal > 0) {
            textGoalWeight.setText("Goal Weight: " + savedGoal + " lb");
        } else {
            textGoalWeight.setText("Goal Weight: Not set");
        }

        buttonUpdateGoal.setOnClickListener(v -> {
            String goalText = editGoalWeight.getText().toString().trim();

            if (goalText.isEmpty()) {
                Toast.makeText(this,
                        "Enter a goal weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double goal = Double.parseDouble(goalText);

                if (!Double.isFinite(goal) || goal <= 0) {
                    Toast.makeText(this,
                            "Enter a valid goal weight",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                preferences.edit()
                        .putLong(goalKey, Double.doubleToLongBits(goal))
                        .putBoolean("goal_alert_" + userId, false)
                        .apply();


                textGoalWeight.setText("Goal Weight: " + goal + " lb");
                editGoalWeight.setText("");

                Toast.makeText(this,
                        "Goal weight updated!",
                        Toast.LENGTH_SHORT).show();

            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Enter a valid number",
                        Toast.LENGTH_SHORT).show();
            }
        });


        // Save a new weight entry.
        buttonAddWeight.setOnClickListener(v -> {
            String date = editDate.getText().toString().trim();
            String weightText = editWeight.getText().toString().trim();

            if (date.isEmpty() || weightText.isEmpty()) {
                Toast.makeText(this,
                        "Enter a date and weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightText);

                if (weight <= 0) {
                    Toast.makeText(this,
                            "Enter a valid weight",
                            Toast.LENGTH_SHORT).show();
                    return;
                }


                // Update an existing entry or save a new one.
                boolean saved;

                if (editingWeightId != -1) {
                    saved = databaseHelper.updateWeight(
                            editingWeightId, weight, date);
                } else {
                    saved = databaseHelper.addWeight(
                            userId, weight, date);
                }


                if (saved) {
                    Toast.makeText(this,
                            "Weight saved successfully!",
                            Toast.LENGTH_SHORT).show();

                    editDate.setText("");
                    editWeight.setText("");

                    // Return to adding new weight entries.
                    editingWeightId = -1;


                    loadWeights();

                    // Check whether the user has reached their goal.
                    SharedPreferences goalPreferences = getSharedPreferences(
                            "WeightGoals", MODE_PRIVATE);

                    double goalWeight = Double.longBitsToDouble(
                            goalPreferences.getLong(
                                    "goal_" + userId,
                                    Double.doubleToLongBits(0.0)));

                    // Remember whether this goal has already been reached.
                    String alertKey = "goal_alert_" + userId;
                    boolean alertSent = goalPreferences.getBoolean(
                            alertKey, false);


                    if (goalWeight > 0 && weight <= goalWeight && !alertSent) {
                        Toast.makeText(this,
                                "Congratulations! You reached your goal!",
                                Toast.LENGTH_LONG).show();

                        goalPreferences.edit()
                                .putBoolean(alertKey, true)
                                .apply();


                        // Pixel 6a emulator test number.
                        String testPhoneNumber = "5556";

                        // Only prepare an SMS alert if permission was granted.
                        if (ActivityCompat.checkSelfPermission(
                                this, Manifest.permission.SEND_SMS)
                                == PackageManager.PERMISSION_GRANTED) {


                            try {
                                SmsManager smsManager = getSystemService(SmsManager.class);

                                Intent sentIntent = new Intent("SMS_SENT");
                                sentIntent.setPackage(getPackageName());

                                PendingIntent sentPendingIntent = PendingIntent.getBroadcast(
                                        this,
                                        0,
                                        sentIntent,
                                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                                );

                                BroadcastReceiver sentReceiver = new BroadcastReceiver() {
                                    @Override
                                    public void onReceive(Context context, Intent intent) {
                                        if (getResultCode() == Activity.RESULT_OK) {
                                            Toast.makeText(context, "SMS sent successfully",
                                                    Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(context, "SMS sending failed",
                                                    Toast.LENGTH_LONG).show();
                                        }
                                        unregisterReceiver(this);
                                    }
                                };

                                ContextCompat.registerReceiver(
                                        this,
                                        sentReceiver,
                                        new IntentFilter("SMS_SENT"),
                                        ContextCompat.RECEIVER_NOT_EXPORTED
                                );


                                smsManager.sendTextMessage(
                                        testPhoneNumber,
                                        null,
                                        "Weight Tracker: Congratulations! You reached your goal weight!",
                                        sentPendingIntent,
                                        null
                                );

                                Toast.makeText(this,
                                        "SMS send requested",
                                        Toast.LENGTH_SHORT).show();

                            } catch (Exception e) {
                                Toast.makeText(this,
                                        "SMS could not be sent",
                                        Toast.LENGTH_SHORT).show();
                            }


                        } else {
                            Toast.makeText(this,
                                    "SMS permission denied - weight still saved",
                                    Toast.LENGTH_SHORT).show();
                        }


                    }

                } else {
                    Toast.makeText(this,
                            "Could not save weight",
                            Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Enter a valid weight number",
                        Toast.LENGTH_SHORT).show();

            }
        });
                loadWeights();
    }

    // Display the user's saved weight entries.
    private void loadWeights() {
        // Keep the table headings and remove old data rows.
        tableWeightHistory.removeViews(
                1, tableWeightHistory.getChildCount() - 1);

        try (Cursor cursor = databaseHelper.getWeights(userId)) {

            // Display the most recent saved weight.
            if (cursor.moveToFirst()) {
                double latestWeight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight"));

                textCurrentWeight.setText(
                        "Current Weight: " + latestWeight + " lb");
            } else {
                textCurrentWeight.setText("Current Weight: No entries yet");
            }

            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                // Get the ID of this saved weight entry.
                int weightId = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("date"));
                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight"));

                TableRow row = new TableRow(this);

                TextView dateView = new TextView(this);
                dateView.setText(date);
                dateView.setPadding(6, 6, 6, 6);
                row.addView(dateView);

                // Display the saved weight.
                TextView weightView = new TextView(this);
                weightView.setText(weight + " lb");
                weightView.setPadding(6, 6, 6, 6);
                row.addView(weightView);



                // Edit an existing weight entry.
                Button editButton = new Button(this);
                editButton.setText("Edit");

                editButton.setOnClickListener(v -> {
                    editingWeightId = weightId;

                    editDate.setText(date);
                    editWeight.setText(String.valueOf(weight));

                    Toast.makeText(this,
                            "Change the weight and date, then save",
                            Toast.LENGTH_SHORT).show();
                });

                row.addView(editButton);


                // Delete this saved weight entry.
                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");

                deleteButton.setOnClickListener(v -> {
                    boolean deleted = databaseHelper.deleteWeight(weightId);

                    if (deleted) {
                        Toast.makeText(this,
                                "Weight deleted successfully!",
                                Toast.LENGTH_SHORT).show();
                        loadWeights();
                    } else {
                        Toast.makeText(this,
                                "Could not delete weight",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                row.addView(deleteButton);

                tableWeightHistory.addView(row);

            }
        }
    }

}
