
package com.example.weighttracker_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Save user login information.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, password TEXT)");

        // Save weight entries for each user.
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, weight REAL, " +
                "date TEXT, FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    // Add a new user account.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        return db.insert("users", null, values) != -1;
    }

    // Check login information.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password})) {
            return cursor.moveToFirst();
        }
    }

    // Save a weight entry.
    public boolean addWeight(int userId, double weight, String date) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("date", date);

        return db.insert("weights", null, values) != -1;
    }

    // Retrieve a user's weight entries.
    public Cursor getWeights(int userId) {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM weights WHERE user_id=? ORDER BY date DESC",
                new String[]{String.valueOf(userId)});
    }

    // Update a saved weight.
    public boolean updateWeight(int id, double weight, String date) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("weight", weight);
        values.put("date", date);

        return db.update("weights", values, "id=?",
                new String[]{String.valueOf(id)}) > 0;
    }

    // Delete a weight entry.
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("weights", "id=?",
                new String[]{String.valueOf(id)}) > 0;
    }

    // Find the database ID for a username.
    public int getUserId(String username) {
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=?",
                new String[]{username})) {

            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        }

        return -1;
    }

}
