
package com.example.weighttracker_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        // Connect the Java code to the login screen.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        // Log in with an existing account.
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (databaseHelper.checkUser(username, password)) {
                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this,
                        WeightDashboardActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);


                // We will connect the dashboard in the next step.
            } else {
                Toast.makeText(this,
                        "Incorrect username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Create a new user account.
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.addUser(username, password);

            if (created) {
                Toast.makeText(this,
                        "Account created! You can now log in.",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,
                        "Username already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
